typedef struct user_input input;
// typedef struct connection conn;
void handleConnection(void *arguments);